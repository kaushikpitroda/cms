<?php
 
namespace Rullion\Cms\Helper;
 
use Magento\Framework\App\Helper\AbstractHelper;
 
class Data extends AbstractHelper
{
    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $scopeConfig;
	const XML_PATH_DISPLAY_OPTION = 'cmssetting/general/langVar';

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) 
    {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
    }
 
    public function getLanguageVariable($storeCode, $locale) {
	 	$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		$variableValue = $this->scopeConfig->getValue(self::XML_PATH_DISPLAY_OPTION, $storeScope, $storeCode);
		return array('locale' => $locale, 'languageVar' => $variableValue);
		

    }
}