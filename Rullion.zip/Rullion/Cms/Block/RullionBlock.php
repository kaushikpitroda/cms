<?php
namespace Rullion\Cms\Block;
use \Magento\Store\Model\ScopeInterface as MagentoStoreModelScopeInterface; 
class RullionBlock extends \Magento\Framework\View\Element\Template
{
	protected $_session;
	protected $_context;

	public function __construct(
	 \Magento\Framework\View\Element\Template\Context $context,
	 \Magento\Store\Model\StoreManagerInterface $storeManager,
	 \Magento\Store\Model\StoreFactory $storeFactory,
	 \Magento\Cms\Model\Page $page,
	 \Rullion\Cms\Helper\Data $moduleHelper,
	 \Magento\Framework\UrlInterface $urlInterface
	) {     
		parent::__construct($context);
        $this->_storeManager = $storeManager;    
		$this->_page = $page;
		$this->_storeFactory = $storeFactory;
		$this->_helper = $moduleHelper;
        $this->_urlInterface = $urlInterface;
		$this->objManager = \Magento\Framework\App\ObjectManager::getInstance();

	} 
	/**
     * Get page id
     *
     * @return  int
     */
    public function getPageId()
    {
		if ($this->_page->getId()) {
			$pageId = $this->_page->getId();
			return $pageId;
		}
    }
	/**
     * Get Page Websites
     *
     * @return  array
     */
	public function getPageWebsites() {
		
		$storeIds = $this->_page->getStoreId();
		$scopeConfig = $this->objManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
		foreach($storeIds as $storeId) {
			$storeCollection = $this->_storeFactory->create()->getCollection()->addFieldToFilter('store_id', $storeId)->getFirstItem();
			if($storeCollection->getWebsiteId() == $this->getWebsiteId()) {
				$locale = $scopeConfig->getValue('general/locale/code', MagentoStoreModelScopeInterface::SCOPE_STORE, $storeId);
				$storeCode = $storeCollection->getCode();
				return array('code' => $storeCode,'locale' => $locale);
			}
		}
	
	}
	/**
     * Get Custom Language Variable from system config
     *
     * @return  array
     */
	public function getLanguageVariable() {
		$websiteDetails = $this->getPageWebsites();
		return $this->_helper->getLanguageVariable($websiteDetails['code'], $websiteDetails['locale']);
	}
    /**
     * Get current store id
     *
     * @return  int
     */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }
    
    /**
     * Get website identifier
     *
     * @return string|int|null
     */
    public function getWebsiteId()
    {
        return $this->_storeManager->getStore()->getWebsiteId();
    }
    
    /**
     * Get Page Identifier
     *
     * @return string
     */
    public function getPageIdentifier()
    {
        return $this->_page->getIdentifier();
    }
    
	/**
     * Get Base URL
     *
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->_urlInterface->getBaseUrl();
    }
}